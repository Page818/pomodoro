# Store

Pinia stores are used to store reactive state and expose actions to mutate it.

Full documentation for this feature can be found in the Official [Pinia](https://pinia.esm.dev/) repository.
