<template>
  <v-card>A</v-card>
</template>
